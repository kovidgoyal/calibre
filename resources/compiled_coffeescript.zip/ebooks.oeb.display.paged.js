
/*
 Copyright 2012, Kovid Goyal <kovid@kovidgoyal.net>
 Released under the GPLv3 License
*/


(function() {
  var PagedDisplay, abstop, body_height;

  body_height = function() {
    var db, dde;
    db = document.body;
    dde = document.documentElement;
    if ((db != null) && (dde != null)) {
      return Math.max(db.scrollHeight, dde.scrollHeight, db.offsetHeight, dde.offsetHeight, db.clientHeight, dde.clientHeight);
    }
    return 0;
  };

  abstop = function(elem) {
    var ans;
    ans = elem.offsetTop;
    while (elem.offsetParent) {
      elem = elem.offsetParent;
      ans += elem.offsetTop;
    }
    return ans;
  };

  PagedDisplay = (function() {

    PagedDisplay.name = 'PagedDisplay';

    /*
        This class is a namespace to expose functions via the
        window.paged_display object. The most important functions are:
    
        layout(): which causes the currently loaded document to be laid out in columns.
    */


    function PagedDisplay(cols_per_screen, top_margin, side_margin, bottom_margin) {
      if (cols_per_screen == null) {
        cols_per_screen = 2;
      }
      if (top_margin == null) {
        top_margin = 10;
      }
      if (side_margin == null) {
        side_margin = 10;
      }
      if (bottom_margin == null) {
        bottom_margin = 10;
      }
      this.top_margin = top_margin;
      this.side_margin = side_margin;
      this.bottom_margin = bottom_margin;
      this.cols_per_screen = cols_per_screen;
    }

    PagedDisplay.prototype.layout = function() {
      var wh, ww;
      ww = window.innerWidth;
      return wh = window.innerHeight;
    };

    return PagedDisplay;

  })();

  if (typeof window !== "undefined" && window !== null) {
    window.paged_display = new PagedDisplay();
  }

}).call(this);

