
/*
 Copyright 2012, Kovid Goyal <kovid@kovidgoyal.net>
 Released under the GPLv3 License
*/


(function() {
  var PagedDisplay, absleft, log, viewport_to_document, window_scroll_pos,
    __slice = [].slice;

  log = function() {
    var args, msg, _ref, _ref1;
    args = 1 <= arguments.length ? __slice.call(arguments, 0) : [];
    if (args) {
      msg = args.join(' ');
      if (typeof window !== "undefined" && window !== null ? (_ref = window.console) != null ? _ref.log : void 0 : void 0) {
        return window.console.log(msg);
      } else if (typeof process !== "undefined" && process !== null ? (_ref1 = process.stdout) != null ? _ref1.write : void 0 : void 0) {
        return process.stdout.write(msg + '\n');
      }
    }
  };

  window_scroll_pos = function(win) {
    var x, y;
    if (win == null) {
      win = window;
    }
    if (typeof win.pageXOffset === 'number') {
      x = win.pageXOffset;
      y = win.pageYOffset;
    } else {
      if (document.body && (document.body.scrollLeft || document.body.scrollTop)) {
        x = document.body.scrollLeft;
        y = document.body.scrollTop;
      } else if (document.documentElement && (document.documentElement.scrollLeft || document.documentElement.scrollTop)) {
        y = document.documentElement.scrollTop;
        x = document.documentElement.scrollLeft;
      }
    }
    return [x, y];
  };

  viewport_to_document = function(x, y, doc) {
    var frame, rect, win, wx, wy, _ref;
    if (doc == null) {
      doc = typeof window !== "undefined" && window !== null ? window.document : void 0;
    }
    while (doc !== window.document) {
      frame = doc.defaultView.frameElement;
      rect = frame.getBoundingClientRect();
      x += rect.left;
      y += rect.top;
      doc = frame.ownerDocument;
    }
    win = doc.defaultView;
    _ref = window_scroll_pos(win), wx = _ref[0], wy = _ref[1];
    x += wx;
    y += wy;
    return [x, y];
  };

  absleft = function(elem) {
    var r;
    r = elem.getBoundingClientRect();
    return viewport_to_document(r.left, 0, elem.ownerDocument)[0];
  };

  PagedDisplay = (function() {

    PagedDisplay.name = 'PagedDisplay';

    function PagedDisplay() {
      if (!this instanceof arguments.callee) {
        throw new Error('PagedDisplay constructor called as function');
      }
      this.set_geometry();
      this.page_width = 0;
      this.screen_width = 0;
      this.in_paged_mode = false;
      this.current_margin_side = 0;
      this.is_full_screen_layout = false;
      this.max_col_width = -1;
    }

    PagedDisplay.prototype.set_geometry = function(cols_per_screen, margin_top, margin_side, margin_bottom) {
      if (cols_per_screen == null) {
        cols_per_screen = 1;
      }
      if (margin_top == null) {
        margin_top = 20;
      }
      if (margin_side == null) {
        margin_side = 40;
      }
      if (margin_bottom == null) {
        margin_bottom = 20;
      }
      this.margin_top = margin_top;
      this.margin_side = margin_side;
      this.margin_bottom = margin_bottom;
      return this.cols_per_screen = cols_per_screen;
    };

    PagedDisplay.prototype.layout = function() {
      var adjust, body_style, bs, col_width, cprop, edge, extra_margin, fgcolor, first_layout, has_svg, margin_top, n, only_img, priority, prop, rule, sheet, single_screen, sm, val, ww, _i, _j, _k, _l, _len, _len1, _len2, _len3, _ref, _ref1, _ref2, _ref3;
      body_style = window.getComputedStyle(document.body);
      first_layout = false;
      if (!this.in_paged_mode) {
        document.body.style.marginTop = '0px';
        extra_margin = document.body.getBoundingClientRect().top;
        margin_top = (this.margin_top - extra_margin) + 'px';
        single_screen = document.body.scrollWidth < window.innerWidth + 25 && document.body.scrollHeight < window.innerHeight + 25;
        first_layout = true;
      } else {
        margin_top = body_style.marginTop;
      }
      ww = window.innerWidth;
      n = this.cols_per_screen;
      adjust = ww - Math.floor(ww / n) * n;
      sm = Math.max(2 * adjust, this.margin_side);
      col_width = Math.max(100, ((ww - adjust) / n) - 2 * sm);
      if (this.max_col_width > 0 && col_width > this.max_col_width) {
        sm += Math.ceil((col_width - this.max_col_width) / 2 * n);
        col_width = Math.max(100, ((ww - adjust) / n) - 2 * sm);
      }
      this.page_width = col_width + 2 * sm;
      this.screen_width = this.page_width * this.cols_per_screen;
      fgcolor = body_style.getPropertyValue('color');
      bs = document.body.style;
      bs.setProperty('-webkit-column-gap', (2 * sm) + 'px');
      bs.setProperty('-webkit-column-width', col_width + 'px');
      bs.setProperty('-webkit-column-rule-color', fgcolor);
      bs.setProperty('overflow', 'visible');
      bs.setProperty('height', (window.innerHeight - this.margin_top - this.margin_bottom) + 'px');
      bs.setProperty('width', (window.innerWidth - 2 * sm) + 'px');
      bs.setProperty('margin-top', margin_top);
      bs.setProperty('margin-bottom', this.margin_bottom + 'px');
      bs.setProperty('margin-left', sm + 'px');
      bs.setProperty('margin-right', sm + 'px');
      _ref = ['left', 'right', 'top', 'bottom'];
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        edge = _ref[_i];
        bs.setProperty('padding-' + edge, '0px');
        bs.setProperty('border-' + edge + '-width', '0px');
      }
      bs.setProperty('min-width', '0');
      bs.setProperty('max-width', 'none');
      bs.setProperty('min-height', '0');
      bs.setProperty('max-height', 'none');
      _ref1 = document.styleSheets;
      for (_j = 0, _len1 = _ref1.length; _j < _len1; _j++) {
        sheet = _ref1[_j];
        _ref2 = sheet.rules;
        for (_k = 0, _len2 = _ref2.length; _k < _len2; _k++) {
          rule = _ref2[_k];
          if (rule.type === 1) {
            _ref3 = ['page-break-before', 'page-break-after', 'page-break-inside'];
            for (_l = 0, _len3 = _ref3.length; _l < _len3; _l++) {
              prop = _ref3[_l];
              val = rule.style.getPropertyValue(prop);
              if (val) {
                cprop = '-webkit-column-' + prop.substr(5);
                priority = rule.style.getPropertyPriority(prop);
                rule.style.setProperty(cprop, val, priority);
              }
            }
          }
        }
      }
      if (first_layout) {
        has_svg = document.getElementsByTagName('svg').length > 0;
        only_img = document.getElementsByTagName('img').length === 1 && document.getElementsByTagName('div').length < 2 && document.getElementsByTagName('p').length < 2;
        this.is_full_screen_layout = (only_img || has_svg) && single_screen && document.body.scrollWidth > document.body.clientWidth;
      }
      this.in_paged_mode = true;
      this.current_margin_side = sm;
      return sm;
    };

    PagedDisplay.prototype.scroll_to_pos = function(frac) {
      var xpos;
      xpos = Math.floor(document.body.scrollWidth * frac);
      return this.scroll_to_xpos(xpos);
    };

    PagedDisplay.prototype.scroll_to_xpos = function(xpos, animated, notify, duration) {
      var limit, pos;
      if (animated == null) {
        animated = false;
      }
      if (notify == null) {
        notify = false;
      }
      if (duration == null) {
        duration = 1000;
      }
      if (typeof xpos !== 'number') {
        log(xpos, 'is not a number, cannot scroll to it!');
        return;
      }
      if (this.is_full_screen_layout) {
        window.scrollTo(0, 0);
        return;
      }
      pos = Math.floor(xpos / this.page_width) * this.page_width;
      limit = document.body.scrollWidth - this.screen_width;
      if (pos > limit) {
        pos = limit;
      }
      if (animated) {
        return this.animated_scroll(pos, duration = 1000, notify = notify);
      } else {
        return window.scrollTo(pos, 0);
      }
    };

    PagedDisplay.prototype.column_at = function(xpos) {
      return Math.floor(xpos / this.page_width);
    };

    PagedDisplay.prototype.column_boundaries = function() {
      var l;
      l = this.column_at(window.pageXOffset + 10);
      return [l, l + this.cols_per_screen];
    };

    PagedDisplay.prototype.animated_scroll = function(pos, duration, notify) {
      var delta, interval, step_size, steps,
        _this = this;
      if (duration == null) {
        duration = 1000;
      }
      if (notify == null) {
        notify = true;
      }
      delta = pos - window.pageXOffset;
      interval = 50;
      steps = Math.floor(duration / interval);
      step_size = Math.floor(delta / steps);
      this.current_scroll_animation = {
        target: pos,
        step_size: step_size,
        interval: interval,
        notify: notify,
        fn: function() {
          var a, completed, npos;
          a = _this.current_scroll_animation;
          npos = window.pageXOffset + a.step_size;
          completed = false;
          if (Math.abs(npos - a.target) < Math.abs(a.step_size)) {
            completed = true;
            npos = a.target;
          }
          window.scrollTo(npos, 0);
          if (completed) {
            if (notify) {
              return window.py_bridge.animated_scroll_done();
            }
          } else {
            return setTimeout(a.fn, a.interval);
          }
        }
      };
      return this.current_scroll_animation.fn();
    };

    PagedDisplay.prototype.current_pos = function(frac) {
      var limit;
      limit = document.body.scrollWidth - window.innerWidth;
      if (limit <= 0) {
        return 0.0;
      }
      return window.pageXOffset / limit;
    };

    PagedDisplay.prototype.current_column_location = function() {
      var x;
      if (this.is_full_screen_layout) {
        return 0;
      }
      x = window.pageXOffset + Math.max(10, this.current_margin_side);
      return Math.floor(x / this.page_width) * this.page_width;
    };

    PagedDisplay.prototype.next_screen_location = function() {
      var ans, cc, limit;
      if (this.is_full_screen_layout) {
        return -1;
      }
      cc = this.current_column_location();
      ans = cc + this.screen_width;
      limit = document.body.scrollWidth - window.innerWidth;
      if (ans > limit) {
        ans = window.pageXOffset < limit ? limit : -1;
      }
      return ans;
    };

    PagedDisplay.prototype.previous_screen_location = function() {
      var ans, cc;
      if (this.is_full_screen_layout) {
        return -1;
      }
      cc = this.current_column_location();
      ans = cc - this.screen_width;
      if (ans < 0) {
        ans = window.pageXOffset > 15 ? 0 : -1;
      }
      return ans;
    };

    PagedDisplay.prototype.next_col_location = function() {
      var ans, cc, limit;
      if (this.is_full_screen_layout) {
        return -1;
      }
      cc = this.current_column_location();
      ans = cc + this.page_width;
      limit = document.body.scrollWidth - window.innerWidth;
      if (ans > limit) {
        ans = window.pageXOffset < limit ? limit : -1;
      }
      return ans;
    };

    PagedDisplay.prototype.previous_col_location = function() {
      var ans, cc;
      if (this.is_full_screen_layout) {
        return -1;
      }
      cc = this.current_column_location();
      ans = cc - this.page_width;
      if (ans < 0) {
        ans = window.pageXOffset > 0 ? 0 : -1;
      }
      return ans;
    };

    PagedDisplay.prototype.jump_to_anchor = function(name) {
      var elem, elems;
      elem = document.getElementById(name);
      if (!elem) {
        elems = document.getElementsByName(name);
        if (elems) {
          elem = elems[0];
        }
      }
      if (!elem) {
        return;
      }
      elem.scrollIntoView();
      if (this.in_paged_mode) {
        return this.scroll_to_xpos(absleft(elem) + 5);
      }
    };

    PagedDisplay.prototype.snap_to_selection = function() {
      var doc, left, node, r, sel;
      if (this.in_paged_mode) {
        sel = window.getSelection();
        r = sel.getRangeAt(0).getBoundingClientRect();
        node = sel.anchorNode;
        left = viewport_to_document(r.left, r.top, doc = node.ownerDocument)[0];
        return this.scroll_to_xpos(left + 5);
      }
    };

    PagedDisplay.prototype.jump_to_cfi = function(cfi) {
      var _this = this;
      return window.cfi.scroll_to(cfi, function(x, y) {
        if (_this.in_paged_mode) {
          return _this.scroll_to_xpos(x);
        } else {
          return window.scrollTo(0, y);
        }
      });
    };

    PagedDisplay.prototype.current_cfi = function() {
      var ans, c, cfi, curx, cury, deltax, deltay, left, right, x, _i, _len, _ref, _ref1;
      ans = null;
      if (!(window.cfi != null)) {
        return ans;
      }
      if (this.in_paged_mode) {
        c = this.current_column_location();
        _ref = [c, c - this.page_width, c + this.page_width];
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
          x = _ref[_i];
          _ref1 = [x, x + this.page_width], left = _ref1[0], right = _ref1[1];
          if (left < 0 || right > document.body.scrollWidth) {
            continue;
          }
          deltax = Math.floor(this.page_width / 25);
          deltay = Math.floor(window.innerHeight / 25);
          cury = this.margin_top;
          while (!(cury >= (window.innerHeight - this.margin_bottom))) {
            curx = left + this.current_margin_side;
            while (!(curx >= (right - this.current_margin_side))) {
              cfi = window.cfi.at_point(curx - window.pageXOffset, cury - window.pageYOffset);
              if (cfi) {
                log('Viewport cfi:', cfi);
                return cfi;
              }
              curx += deltax;
            }
            cury += deltay;
          }
        }
      } else {
        try {
          ans = window.cfi.at_current();
          if (!ans) {
            ans = null;
          }
        } catch (err) {
          log(err);
        }
      }
      if (ans) {
        log('Viewport cfi:', ans);
      }
      return ans;
    };

    return PagedDisplay;

  })();

  if (typeof window !== "undefined" && window !== null) {
    window.paged_display = new PagedDisplay();
  }

}).call(this);

