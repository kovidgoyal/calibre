
/*
 Copyright 2013, Kovid Goyal <kovid at kovidgoyal.net>
 Released under the GPLv3 License
*/


(function() {
  var INHERITED_PROPS, PreviewIntegration, find_containing_block, get_matched_css, get_sourceline_address, get_style_properties, in_table, is_block, is_hidden, log, process_rules,
    __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  if (typeof window !== "undefined" && window !== null ? window.calibre_utils : void 0) {
    log = window.calibre_utils.log;
  }

  is_hidden = function(elem) {
    while (elem) {
      if (elem.style && (elem.style.visibility === 'hidden' || elem.style.display === 'none')) {
        return true;
      }
      elem = elem.parentNode;
    }
    return false;
  };

  is_block = function(elem) {
    var style, _ref;
    style = window.getComputedStyle(elem);
    return (_ref = style.display) === 'block' || _ref === 'flex-box' || _ref === 'box';
  };

  in_table = function(elem) {
    var _ref;
    while (elem) {
      if (((_ref = elem.tagName) != null ? _ref.toLowerCase() : void 0) === 'table') {
        return true;
      }
      elem = elem.parentNode;
    }
    return false;
  };

  find_containing_block = function(elem) {
    while (elem && elem.getAttribute('data-is-block') !== '1') {
      elem = elem.parentNode;
    }
    return elem;
  };

  INHERITED_PROPS = {
    'azimuth': '2',
    'border-collapse': '2',
    'border-spacing': '2',
    'caption-side': '2',
    'color': '2',
    'cursor': '2',
    'direction': '2',
    'elevation': '2',
    'empty-cells': '2',
    'fit': '3',
    'fit-position': '3',
    'font': '2',
    'font-family': '2',
    'font-size': '2',
    'font-size-adjust': '2',
    'font-stretch': '2',
    'font-style': '2',
    'font-variant': '2',
    'font-weight': '2',
    'hanging-punctuation': '3',
    'hyphenate-after': '3',
    'hyphenate-before': '3',
    'hyphenate-character': '3',
    'hyphenate-lines': '3',
    'hyphenate-resource': '3',
    'hyphens': '3',
    'image-resolution': '3',
    'letter-spacing': '2',
    'line-height': '2',
    'line-stacking': '3',
    'line-stacking-ruby': '3',
    'line-stacking-shift': '3',
    'line-stacking-strategy': '3',
    'list-style': '2',
    'list-style-image': '2',
    'list-style-position': '2',
    'list-style-type': '2',
    'marquee-direction': '3',
    'orphans': '2',
    'overflow-style': '3',
    'page': '2',
    'page-break-inside': '2',
    'pitch': '2',
    'pitch-range': '2',
    'presentation-level': '3',
    'punctuation-trim': '3',
    'quotes': '2',
    'richness': '2',
    'ruby-align': '3',
    'ruby-overhang': '3',
    'ruby-position': '3',
    'speak': '2',
    'speak-header': '2',
    'speak-numeral': '2',
    'speak-punctuation': '2',
    'speech-rate': '2',
    'stress': '2',
    'text-align': '2',
    'text-align-last': '3',
    'text-emphasis': '3',
    'text-height': '3',
    'text-indent': '2',
    'text-justify': '3',
    'text-outline': '3',
    'text-replace': '?',
    'text-shadow': '3',
    'text-transform': '2',
    'text-wrap': '3',
    'visibility': '2',
    'voice-balance': '3',
    'voice-family': '2',
    'voice-rate': '3',
    'voice-pitch': '3',
    'voice-pitch-range': '3',
    'voice-stress': '3',
    'voice-volume': '3',
    'volume': '2',
    'white-space': '2',
    'white-space-collapse': '3',
    'widows': '2',
    'word-break': '3',
    'word-spacing': '2',
    'word-wrap': '3',
    '-moz-force-broken-image-icon': 'm',
    '-moz-image-region': 'm',
    '-moz-stack-sizing': 'm',
    '-moz-user-input': 'm',
    '-x-system-font': 'm',
    '-xv-voice-balance': 'o',
    '-xv-voice-pitch': 'o',
    '-xv-voice-pitch-range': 'o',
    '-xv-voice-rate': 'o',
    '-xv-voice-stress': 'o',
    '-xv-voice-volume': 'o',
    '-ms-text-align-last': 'e',
    '-ms-text-justify': 'e',
    '-ms-word-break': 'e',
    '-ms-word-wrap': 'e'
  };

  get_sourceline_address = function(node) {
    var elem, sourceline, tags, _i, _len, _ref;
    sourceline = parseInt(node.getAttribute('data-lnum'));
    tags = [];
    _ref = document.querySelectorAll('[data-lnum="' + sourceline + '"]');
    for (_i = 0, _len = _ref.length; _i < _len; _i++) {
      elem = _ref[_i];
      tags.push(elem.tagName.toLowerCase());
      if (elem === node) {
        break;
      }
    }
    return [sourceline, tags];
  };

  get_style_properties = function(style, all_properties, node_style, is_ancestor) {
    var i, properties, property, val, _ref;
    i = 0;
    properties = [];
    while (i < style.length) {
      property = (_ref = style.item(i)) != null ? _ref.toLowerCase() : void 0;
      val = style.getPropertyValue(property);
      if (property && val && (!is_ancestor || INHERITED_PROPS.hasOwnProperty(property))) {
        properties.push([property, val, style.getPropertyPriority(property)]);
        if (!all_properties.hasOwnProperty(property)) {
          all_properties[property] = node_style.getPropertyValue(property);
        }
      }
      i += 1;
    }
    return properties;
  };

  process_rules = function(node, cssRules, address, sheet, sheet_index, matching_selectors, all_properties, node_style, is_ancestor, ans) {
    var data, href, parts, properties, q, rule, rule_address, rule_index, st, type, _i, _j, _len, _len1, _results;
    _results = [];
    for (rule_index = _i = 0, _len = cssRules.length; _i < _len; rule_index = ++_i) {
      rule = cssRules[rule_index];
      rule_address = address + [rule_index];
      if (rule.type === CSSRule.MEDIA_RULE) {
        process_rules(node, rule.cssRules, rule_address, sheet, sheet_index, matching_selectors, all_properties, node_style, is_ancestor, ans);
        continue;
      }
      if (rule.type !== CSSRule.STYLE_RULE) {
        continue;
      }
      st = rule.selectorText;
      if (st && (matching_selectors.hasOwnProperty(st) || (rule_address.length > 1 && node.webkitMatchesSelector(st)))) {
        type = 'sheet';
        href = sheet.href;
        if (href === null) {
          href = get_sourceline_address(sheet.ownerNode);
          type = 'elem';
        }
        parts = st.split(',');
        if (parts.length > 1) {
          for (_j = 0, _len1 = parts.length; _j < _len1; _j++) {
            q = parts[_j];
            if (node.webkitMatchesSelector(q)) {
              st = q;
              break;
            }
          }
        }
        properties = get_style_properties(rule.style, all_properties, node_style, is_ancestor);
        if (properties.length > 0) {
          data = {
            'selector': st,
            'type': type,
            'href': href,
            'properties': properties,
            'rule_address': rule_address,
            'sheet_index': sheet_index
          };
          _results.push(ans.push(data));
        } else {
          _results.push(void 0);
        }
      } else {
        _results.push(void 0);
      }
    }
    return _results;
  };

  get_matched_css = function(node, is_ancestor, all_properties) {
    var ans, data, matching_selectors, node_style, properties, rule, rules, sheet, sheet_index, _i, _j, _len, _len1, _ref;
    rules = node.ownerDocument.defaultView.getMatchedCSSRules(node, '');
    if (!rules) {
      rules = [];
    }
    matching_selectors = {};
    for (_i = 0, _len = rules.length; _i < _len; _i++) {
      rule = rules[_i];
      matching_selectors[rule.selectorText] = true;
    }
    ans = [];
    node_style = window.getComputedStyle(node);
    _ref = document.styleSheets;
    for (sheet_index = _j = 0, _len1 = _ref.length; _j < _len1; sheet_index = ++_j) {
      sheet = _ref[sheet_index];
      if (sheet.disabled) {
        continue;
      }
      process_rules(node, sheet.cssRules, [], sheet, sheet_index, matching_selectors, all_properties, node_style, is_ancestor, ans);
    }
    if (node.getAttribute('style')) {
      properties = get_style_properties(node.style, all_properties, node_style, is_ancestor);
      if (properties.length > 0) {
        data = {
          'selector': null,
          'type': 'inline',
          'href': get_sourceline_address(node),
          'properties': properties,
          'rule_address': null,
          'sheet_index': null
        };
        ans.push(data);
      }
    }
    return ans.reverse();
  };

  PreviewIntegration = (function() {

    PreviewIntegration.name = 'PreviewIntegration';

    /*
        # Namespace to expose all the functions used for integration with the Tweak
        # Book Preview Panel.
    */


    function PreviewIntegration() {
      this.live_css = __bind(this.live_css, this);

      this.go_to_anchor = __bind(this.go_to_anchor, this);

      this.onclick = __bind(this.onclick, this);

      this.onload = __bind(this.onload, this);

      this.report_split = __bind(this.report_split, this);

      this.split_mode = __bind(this.split_mode, this);

      this.find_blocks = __bind(this.find_blocks, this);

      this.line_numbers = __bind(this.line_numbers, this);

      this.go_to_line = __bind(this.go_to_line, this);
      if (!this instanceof arguments.callee) {
        throw new Error('PreviewIntegration constructor called as function');
      }
      this.blocks_found = false;
      this.in_split_mode = false;
    }

    PreviewIntegration.prototype.go_to_line = function(lnum) {
      var node, _i, _len, _ref;
      _ref = document.querySelectorAll('[data-lnum="' + lnum + '"]');
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        node = _ref[_i];
        if (is_hidden(node)) {
          continue;
        }
        if (node === document.body) {
          window.scrollTo(0, 0);
        } else {
          node.scrollIntoView();
        }
        return;
      }
    };

    PreviewIntegration.prototype.line_numbers = function() {
      var ans, found_body, node, _i, _len, _ref;
      found_body = false;
      ans = [];
      _ref = document.getElementsByTagName('*');
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        node = _ref[_i];
        if (!found_body && node.tagName.toLowerCase() === "body") {
          found_body = true;
        }
        if (found_body) {
          ans.push(node.getAttribute("data-lnum"));
        }
      }
      return ans;
    };

    PreviewIntegration.prototype.find_blocks = function() {
      var elem, _i, _len, _ref;
      if (this.blocks_found) {
        return;
      }
      _ref = document.body.getElementsByTagName('*');
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        elem = _ref[_i];
        if (is_block(elem) && !in_table(elem)) {
          elem.setAttribute('data-is-block', '1');
        }
      }
      return this.blocks_found = true;
    };

    PreviewIntegration.prototype.split_mode = function(enabled) {
      this.in_split_mode = enabled;
      document.body.setAttribute('data-in-split-mode', enabled ? '1' : '0');
      if (enabled) {
        return this.find_blocks();
      }
    };

    PreviewIntegration.prototype.report_split = function(node) {
      var loc, num, parent, sibling, totals;
      loc = [];
      totals = [];
      parent = find_containing_block(node);
      while (parent && parent.tagName.toLowerCase() !== 'body') {
        totals.push(parent.parentNode.children.length);
        num = 0;
        sibling = parent.previousElementSibling;
        while (sibling) {
          num += 1;
          sibling = sibling.previousElementSibling;
        }
        loc.push(num);
        parent = parent.parentNode;
      }
      loc.reverse();
      totals.reverse();
      return window.py_bridge.request_split(JSON.stringify(loc), JSON.stringify(totals));
    };

    PreviewIntegration.prototype.onload = function() {
      return window.document.body.addEventListener('click', this.onclick, true);
    };

    PreviewIntegration.prototype.onclick = function(event) {
      var e, href, lnum, tn, _ref;
      event.preventDefault();
      if (this.in_split_mode) {
        this.report_split(event.target);
      } else {
        e = event.target;
        lnum = e.getAttribute('data-lnum');
        href = tn = '';
        while (e && e !== document.body && e !== document && (tn !== 'a' || !href)) {
          tn = (_ref = e.tagName) != null ? _ref.toLowerCase() : void 0;
          href = e.getAttribute('href');
          e = e.parentNode;
        }
        window.py_bridge.request_sync(tn, href, lnum);
      }
      return false;
    };

    PreviewIntegration.prototype.go_to_anchor = function(anchor, lnum) {
      var elem;
      elem = document.getElementById(anchor);
      if (!elem) {
        elem = document.querySelector('[name="' + anchor + '"]');
      }
      if (elem) {
        elem.scrollIntoView();
        lnum = elem.getAttribute('data-lnum');
      }
      return window.py_bridge.request_sync('', '', lnum);
    };

    PreviewIntegration.prototype.live_css = function(sourceline, tags) {
      var all_properties, ans, css, i, is_ancestor, node, original_target, target, _i, _len, _ref, _ref1, _ref2;
      target = null;
      i = 0;
      _ref = document.querySelectorAll('[data-lnum="' + sourceline + '"]');
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        node = _ref[_i];
        if (((_ref1 = node.tagName) != null ? _ref1.toLowerCase() : void 0) !== tags[i]) {
          return JSON.stringify(null);
        }
        i += 1;
        target = node;
        if (i >= tags.length) {
          break;
        }
      }
      all_properties = {};
      original_target = target;
      ans = {
        'nodes': [],
        'computed_css': all_properties
      };
      is_ancestor = false;
      while (target && target.ownerDocument) {
        css = get_matched_css(target, is_ancestor, all_properties);
        if (css.length > 0) {
          ans['nodes'].push({
            'name': (_ref2 = target.tagName) != null ? _ref2.toLowerCase() : void 0,
            'css': css,
            'is_ancestor': is_ancestor
          });
        }
        target = target.parentNode;
        is_ancestor = true;
      }
      return JSON.stringify(ans);
    };

    return PreviewIntegration;

  })();

  window.calibre_preview_integration = new PreviewIntegration();

  window.onload = window.calibre_preview_integration.onload;

}).call(this);

